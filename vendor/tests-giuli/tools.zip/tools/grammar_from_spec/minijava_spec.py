from __future__ import annotations
from typing import NamedTuple, Any

EPS = None  # epsilon production (no symbol)

class Token(NamedTuple):
    name: str
    spell: str | None
    pattern: str | None = None
    skip: bool = False

class Fragment(NamedTuple):
    name: str
    pattern: str

class Rule(NamedTuple):
    lhs: str
    alts: tuple[tuple[Any, ...], ...]

def T(name: str, spell: str) -> Token:
    return Token(name, spell, f"'{spell}'")

# --- Keywords ----------------------------------------------------------------
BOOLEAN = T("BOOLEAN", "boolean")
CHAR = T("CHAR", "char")
CLASS = T("CLASS", "class")
ELSE = T("ELSE", "else")
EXTENDS = T("EXTENDS", "extends")
IF = T("IF", "if")
IMPLEMENTS = T("IMPLEMENTS", "implements")
INT = T("INT", "int")
INTERFACE = T("INTERFACE", "interface")
NEW = T("NEW", "new")
PUBLIC = T("PUBLIC", "public")
RETURN = T("RETURN", "return")
STATIC = T("STATIC", "static")
THIS = T("THIS", "this")
VAR = T("VAR", "var")
VOID = T("VOID", "void")
WHILE = T("WHILE", "while")
LIT_BOOLEAN = Token("LIT_BOOLEAN", "booleanLiteral", "'true' | 'false'")

KEYWORDS = {
    "BOOLEAN": BOOLEAN, "CHAR": CHAR, "CLASS": CLASS, "ELSE": ELSE,
    "EXTENDS": EXTENDS, "IF": IF, "IMPLEMENTS": IMPLEMENTS,
    "INT": INT, "INTERFACE": INTERFACE, "NEW": NEW, "PUBLIC": PUBLIC,
    "RETURN": RETURN, "STATIC": STATIC, "THIS": THIS,
    "VAR": VAR, "VOID": VOID, "WHILE": WHILE,
}

# --- Operators & Punctuation -------------------------------------------------
ASSIGNMENT = T("ASSIGNMENT", "=")
ASTERISK = T("ASTERISK", "*")
BANG = T("BANG", "!")
COMMA = T("COMMA", ",")
DOT = T("DOT", ".")
EQUALITY = T("EQUALITY", "==")
GREATER_OR_EQUAL = T("GREATER_OR_EQUAL", ">=")
GREATER_THAN = T("GREATER_THAN", ">")
INEQUALITY = T("INEQUALITY", "!=")
LBRACE = T("LBRACE", "{")
LBRACKET = T("LBRACKET", "[")
LESS_OR_EQUAL = T("LESS_OR_EQUAL", "<=")
LESS_THAN = T("LESS_THAN", "<")
LOGICAL_AND = T("LOGICAL_AND", "&&")
LOGICAL_OR = T("LOGICAL_OR", "||")
LPAREN = T("LPAREN", "(")
MINUS = T("MINUS", "-")
PERCENT = T("PERCENT", "%")
PLUS = T("PLUS", "+")
RBRACE = T("RBRACE", "}")
RBRACKET = T("RBRACKET", "]")
RPAREN = T("RPAREN", ")")
SEMICOLON = T("SEMICOLON", ";")
SLASH = T("SLASH", "/")

# --- Complex Terminals -------------------------------------------------------
ID_CLASS = Token("ID_CLASS", "idClase", r"UPPER (LOWER | '_' | UPPER | DIGIT)+")
ID_TYPE = Token("ID_TYPE", "idGen", r"UPPER")
ID_VAR_METH = Token("ID_VAR_METH", "idMetVar", r"LOWER (LOWER | '_' | UPPER | DIGIT)*")

LIT_CHAR = Token("LIT_CHAR", "charLiteral", r"'\'' (SINGLE_CHAR | ESCAPE_SEQUENCE) '\''")
LIT_INTEGER = Token("LIT_INTEGER", "intLiteral", r"DIGIT DIGIT? DIGIT? DIGIT? DIGIT? DIGIT? DIGIT? DIGIT? DIGIT?")
LIT_NULL = Token("LIT_NULL", "null", "'null'")
LIT_STRING = Token("LIT_STRING", "stringLiteral", "'\"' (STRING_CHAR | ESCAPE_SEQUENCE)* '\"'")
EOF = Token("EOF", "eof")

COMMENT_LINEA = Token("COMMENT_LINEA", None, r"'//' CHAR_ENTRADA*", skip=True)
COMMENT_MULTILINEA = Token("COMMENT_MULTILINEA", None, r"'/*' (NO_STAR | '*'+ NO_STAR_SLASH)* '*'+ '/'", skip=True)
WS = Token("WS", None, r"WHITESPACE_CHAR+", skip=True)

FRAGMENTS = (
    Fragment("CHAR_ENTRADA", r"~[\r\n]"),
    Fragment("SINGLE_CHAR", r"~['\\\r\n]"),
    Fragment("STRING_CHAR", r'~["\\\r\n]'),
    Fragment("NO_STAR", r"~[*]"),
    Fragment("NO_STAR_SLASH", r"~[*/]"),
    Fragment("LINE_TERM", r"'\r\n' | '\r' | '\n'"),
    Fragment("UPPER", r"[A-Z]"),
    Fragment("LOWER", r"[a-z]"),
    Fragment("DIGIT", r"[0-9]"),
    Fragment("WHITESPACE_CHAR", r"LINE_TERM | '\t' | ' '"),
    Fragment("HEX", r"DIGIT | [A-Fa-f]"),
    Fragment("ESCAPABLE", "[btnfr\"'\\\\]"),
    Fragment("ESCAPE_SEQUENCE", r"'\\' (ESCAPABLE | 'u'+ HEX HEX HEX HEX)"),
    Fragment("EXPONENTE", r"[eE] [+-]? DIGIT+"),
    Fragment("SUFIJO_FLOAT", r"[fFdD]"),
)

TOKEN_RULES = (
    ASSIGNMENT, ASTERISK, BANG, BOOLEAN, CHAR, CLASS, COMMA, DOT, ELSE,
    EQUALITY, EXTENDS, GREATER_OR_EQUAL, GREATER_THAN, IF, IMPLEMENTS,
    INEQUALITY, INT, INTERFACE, LBRACE, LBRACKET, LESS_OR_EQUAL, LESS_THAN,
    LIT_BOOLEAN, LIT_CHAR, LIT_INTEGER, LIT_NULL, LIT_STRING, LOGICAL_AND, LOGICAL_OR,
    LPAREN, MINUS, NEW, PERCENT, PLUS, PUBLIC, RBRACE, RBRACKET, RETURN,
    RPAREN, SEMICOLON, SLASH, STATIC, THIS, VAR, VOID, WHILE,
    ID_CLASS, ID_TYPE, ID_VAR_METH,
)

SKIP_RULES = (COMMENT_LINEA, COMMENT_MULTILINEA, WS)

# --- Nonterminals -----------------------------------------------------------
class NT:
    ListaClases = "ListaClases"
    Clase = "Clase"
    Interfaz = "Interfaz"
    HerenciaOpcional = "HerenciaOpcional"
    GenericidadOpcional = "GenericidadOpcional"
    ExtensionOpcional = "ExtensionOpcional"
    ListaMiembros = "ListaMiembros"
    ListaMetodosInterfaz = "ListaMetodosInterfaz"
    Miembro = "Miembro"
    MetodoEstatico = "MetodoEstatico"
    NombreTipado = "NombreTipado"
    ArgsOPuntoYComa = "ArgsOPuntoYComa"
    Metodo = "Metodo"
    MetodoInterfaz = "MetodoInterfaz"
    Constructor = "Constructor"
    TipoMetodo = "TipoMetodo"
    Tipo = "Tipo"
    TipoBase = "TipoBase"
    DimensionesOpcionales = "DimensionesOpcionales"
    TipoReferencia = "TipoReferencia"
    TipoPrimitivo = "TipoPrimitivo"
    TipoGenericoOpcional = "TipoGenericoOpcional"
    InstanciadoOParametrico = "InstanciadoOParametrico"
    ArgsFormales = "ArgsFormales"
    ListaArgsFormalesOpcional = "ListaArgsFormalesOpcional"
    ListaArgsFormales = "ListaArgsFormales"
    ListaArgsFormalesR = "ListaArgsFormalesR"
    ArgFormal = "ArgFormal"
    Bloque = "Bloque"
    ListaSentencias = "ListaSentencias"
    Sentencia = "Sentencia"
    VarLocal = "VarLocal"
    ReturnStmt = "ReturnStmt"
    ExpresionOpcional = "ExpresionOpcional"
    IfStmt = "IfStmt"
    OrElse = "OrElse"
    WhileStmt = "WhileStmt"
    Expresion = "Expresion"
    ExpresionR = "ExpresionR"
    OperadorAsignacion = "OperadorAsignacion"
    ExpresionCompuesta = "ExpresionCompuesta"
    ExpresionCompuestaR = "ExpresionCompuestaR"
    OperadorBinario = "OperadorBinario"
    ExpresionBasica = "ExpresionBasica"
    OperadorUnario = "OperadorUnario"
    Operando = "Operando"
    Primitivo = "Primitivo"
    Referencia = "Referencia"
    ReferenciaR = "ReferenciaR"
    Encadenado = "Encadenado"
    ArgsMetodoEncadenado = "ArgsMetodoEncadenado"
    AccesoArreglo = "AccesoArreglo"
    Primario = "Primario"
    VarOLlamadaMetodo = "VarOLlamadaMetodo"
    NewExpr = "NewExpr"
    ObjetoOArreglo = "ObjetoOArreglo"
    ObjetoOArregloOtraVez = "ObjetoOArregloOtraVez"
    CrearArreglo = "CrearArreglo"
    LlamadaMetodoOpcional = "LlamadaMetodoOpcional"
    LlamadaMetodoEstatico = "LlamadaMetodoEstatico"
    ExpresionParentizada = "ExpresionParentizada"
    DimensionesConTamanio = "DimensionesConTamanio"
    DimensionesConTamanioR = "DimensionesConTamanioR"
    ArgsActuales = "ArgsActuales"
    ListaExpsOpcional = "ListaExpsOpcional"
    ListaExps = "ListaExps"
    ListaExpsR = "ListaExpsR"
    Inicial = "Inicial"

# --- Grammar Rule Helper ----------------------------------------------------
def R(lhs: str, *alts: Any) -> Rule:
    parsed_alts = []
    for alt in alts:
        if alt is None or isinstance(alt, (str, Token)):
            parsed_alts.append((alt,))
        elif isinstance(alt, (tuple, list)):
            parsed_alts.append(tuple(alt))
        else:
            raise TypeError(f"Invalid symbol in rule '{lhs}': {alt!r} (type: {type(alt).__name__})")
    return Rule(lhs, tuple(parsed_alts))

# --- Flat Grammar Rules -----------------------------------------------------
RULES: tuple[Rule, ...] = (
    R(NT.Inicial, (NT.ListaClases, EOF)),
    R(NT.ListaClases, (NT.Clase, NT.ListaClases), (NT.Interfaz, NT.ListaClases), EPS),
    R(NT.Clase, (CLASS, ID_CLASS, NT.GenericidadOpcional, NT.HerenciaOpcional, LBRACE, NT.ListaMiembros, RBRACE)),
    R(NT.Interfaz, (INTERFACE, ID_CLASS, NT.GenericidadOpcional, NT.ExtensionOpcional, LBRACE, NT.ListaMetodosInterfaz, RBRACE)),
    R(NT.GenericidadOpcional, (LESS_THAN, ID_TYPE, GREATER_THAN), EPS),
    R(NT.HerenciaOpcional, (EXTENDS, NT.TipoReferencia), (IMPLEMENTS, NT.TipoReferencia), EPS),
    R(NT.ExtensionOpcional, (EXTENDS, NT.TipoReferencia), EPS),
    R(NT.ListaMiembros, (NT.Miembro, NT.ListaMiembros), EPS),
    R(NT.ListaMetodosInterfaz, (NT.MetodoInterfaz, NT.ListaMetodosInterfaz), EPS),

    R(NT.Miembro, (STATIC, NT.MetodoEstatico), (VOID, NT.Metodo), (PUBLIC, NT.Constructor), (NT.NombreTipado, NT.ArgsOPuntoYComa)),
    R(NT.MetodoEstatico, (NT.TipoMetodo, NT.Metodo)),
    R(NT.NombreTipado, (NT.Tipo, ID_VAR_METH)),
    R(NT.ArgsOPuntoYComa, (NT.ArgsFormales, NT.Bloque), SEMICOLON),
    R(NT.Metodo, (ID_VAR_METH, NT.ArgsFormales, NT.Bloque)),
    R(NT.MetodoInterfaz, (NT.TipoMetodo, ID_VAR_METH, NT.ArgsFormales, SEMICOLON)),
    R(NT.Constructor, (ID_CLASS, NT.ArgsFormales, NT.Bloque)),
    R(NT.TipoMetodo, NT.Tipo, VOID),
    R(NT.Tipo, (NT.TipoBase, NT.DimensionesOpcionales)),
    R(NT.TipoBase, NT.TipoPrimitivo, NT.TipoReferencia, ID_TYPE),
    R(NT.DimensionesOpcionales, (LBRACKET, RBRACKET, NT.DimensionesOpcionales), EPS),
    R(NT.TipoReferencia, (ID_CLASS, NT.TipoGenericoOpcional)),
    R(NT.TipoPrimitivo, BOOLEAN, CHAR, INT),
    R(NT.TipoGenericoOpcional, (LESS_THAN, NT.InstanciadoOParametrico, GREATER_THAN), EPS),
    R(NT.InstanciadoOParametrico, ID_TYPE, ID_CLASS),
    R(NT.ArgsFormales, (LPAREN, NT.ListaArgsFormalesOpcional, RPAREN)),
    R(NT.ListaArgsFormalesOpcional, NT.ListaArgsFormales, EPS),
    R(NT.ListaArgsFormales, (NT.ArgFormal, NT.ListaArgsFormalesR)),
    R(NT.ListaArgsFormalesR, (COMMA, NT.ArgFormal, NT.ListaArgsFormalesR), EPS),
    R(NT.ArgFormal, (NT.Tipo, ID_VAR_METH)),
    R(NT.Bloque, (LBRACE, NT.ListaSentencias, RBRACE)),
    R(NT.ListaSentencias, (NT.Sentencia, NT.ListaSentencias), EPS),

    R(NT.Sentencia, SEMICOLON),
    R(NT.Sentencia, (NT.Expresion, SEMICOLON)),
    R(NT.Sentencia, (NT.VarLocal, SEMICOLON)),
    R(NT.Sentencia, (NT.ReturnStmt, SEMICOLON)),
    R(NT.Sentencia, NT.IfStmt),
    R(NT.Sentencia, NT.WhileStmt),
    R(NT.Sentencia, NT.Bloque),
    R(NT.VarLocal, (VAR, ID_VAR_METH, ASSIGNMENT, NT.ExpresionCompuesta)),
    R(NT.ReturnStmt, (RETURN, NT.ExpresionOpcional)),
    R(NT.ExpresionOpcional, NT.Expresion, EPS),
    R(NT.IfStmt, (IF, LPAREN, NT.Expresion, RPAREN, NT.Sentencia, NT.OrElse)),
    R(NT.OrElse, (ELSE, NT.Sentencia), EPS),
    R(NT.WhileStmt, (WHILE, LPAREN, NT.Expresion, RPAREN, NT.Sentencia)),

    R(NT.Expresion, (NT.ExpresionCompuesta, NT.ExpresionR)),
    R(NT.ExpresionR, (NT.OperadorAsignacion, NT.ExpresionCompuesta, NT.ExpresionR), EPS),
    R(NT.OperadorAsignacion, ASSIGNMENT),
    R(NT.ExpresionCompuesta, (NT.ExpresionBasica, NT.ExpresionCompuestaR)),
    R(NT.ExpresionCompuestaR, (NT.OperadorBinario, NT.ExpresionBasica, NT.ExpresionCompuestaR), EPS),
    R(NT.OperadorBinario, LOGICAL_OR, LOGICAL_AND, EQUALITY, INEQUALITY, LESS_THAN, GREATER_THAN, LESS_OR_EQUAL, GREATER_OR_EQUAL, PLUS, MINUS, ASTERISK, SLASH, PERCENT),
    R(NT.ExpresionBasica, (NT.OperadorUnario, NT.Operando)),
    R(NT.ExpresionBasica, NT.Operando),
    R(NT.OperadorUnario, PLUS, MINUS, BANG),
    R(NT.Operando, NT.Primitivo),
    R(NT.Operando, NT.Referencia),
    R(NT.Primitivo, LIT_BOOLEAN, LIT_INTEGER, LIT_CHAR, LIT_NULL),

    R(NT.Referencia, (NT.Primario, NT.ReferenciaR)),
    R(NT.ReferenciaR, (NT.Encadenado, NT.ReferenciaR), (NT.AccesoArreglo, NT.ReferenciaR), EPS),
    R(NT.Encadenado, (DOT, ID_VAR_METH, NT.ArgsMetodoEncadenado)),
    R(NT.ArgsMetodoEncadenado, NT.ArgsActuales, EPS),
    R(NT.AccesoArreglo, (LBRACKET, NT.Expresion, RBRACKET)),

    R(NT.Primario, THIS),
    R(NT.Primario, LIT_STRING),
    R(NT.Primario, NT.VarOLlamadaMetodo),
    R(NT.Primario, NT.NewExpr),
    R(NT.Primario, NT.LlamadaMetodoEstatico),
    R(NT.Primario, NT.ExpresionParentizada),

    R(NT.VarOLlamadaMetodo, (ID_VAR_METH, NT.LlamadaMetodoOpcional)),
    R(NT.NewExpr, (NEW, NT.ObjetoOArreglo)),
    R(NT.ObjetoOArreglo, (NT.TipoReferencia, NT.ObjetoOArregloOtraVez)),
    R(NT.ObjetoOArreglo, NT.CrearArreglo),
    R(NT.ObjetoOArregloOtraVez, NT.DimensionesConTamanio),
    R(NT.ObjetoOArregloOtraVez, NT.ArgsActuales),
    R(NT.CrearArreglo, (ID_TYPE, NT.DimensionesConTamanio)),
    R(NT.CrearArreglo, (NT.TipoPrimitivo, NT.DimensionesConTamanio)),
    R(NT.LlamadaMetodoOpcional, NT.ArgsActuales, EPS),
    R(NT.LlamadaMetodoEstatico, (ID_CLASS, DOT, ID_VAR_METH, NT.ArgsActuales)),
    R(NT.ExpresionParentizada, (LPAREN, NT.Expresion, RPAREN)),

    R(NT.DimensionesConTamanio, (LBRACKET, NT.Expresion, RBRACKET, NT.DimensionesConTamanioR)),
    R(NT.DimensionesConTamanioR, (LBRACKET, NT.Expresion, RBRACKET, NT.DimensionesConTamanioR), EPS),
    R(NT.ArgsActuales, (LPAREN, NT.ListaExpsOpcional, RPAREN)),
    R(NT.ListaExpsOpcional, NT.ListaExps, EPS),
    R(NT.ListaExps, (NT.Expresion, NT.ListaExpsR)),
    R(NT.ListaExpsR, (COMMA, NT.Expresion, NT.ListaExpsR), EPS),
)

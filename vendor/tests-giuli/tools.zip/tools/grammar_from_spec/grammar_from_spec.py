#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path

import minijava_spec as spec

ROOT = Path(__file__).resolve().parent.parent.parent
OUT = {
    "spec": ROOT / "docs" / "reglas_sintacticas.md",
    "g4": ROOT / "tools" / "grammarinator" / "grammar" / "MiniJava.g4",
    "java": ROOT / "src" / "main" / "java" / "parser" / "MiniJavaGrammar.java",
    "jj": ROOT / "tools" / "grammarinator" / "grammar" / "MiniJavaParser.jj",
}

FRAGMENT_INDEX = {f.name: f.pattern for f in spec.FRAGMENTS}


def backend_name(nt: str) -> str:
    return nt[0].lower() + nt[1:]


def sym_kind(sym):
    if isinstance(sym, spec.Token):
        return "T", sym
    if sym is spec.EPS:
        return "EPS", None
    return "N", sym


def group_rules():
    grouped = {}
    order = []
    for rule in spec.RULES:
        if rule.lhs not in grouped:
            grouped[rule.lhs] = []
            order.append(rule.lhs)
        grouped[rule.lhs].extend(rule.alts)
    return order, grouped


# --- .md --------------------------------------------------------------------

def render_md():
    order, grouped = group_rules()
    lines = []
    for lhs in order:
        rendered = []
        for alt in grouped[lhs]:
            parts = []
            for sym in alt:
                kind, val = sym_kind(sym)
                if kind == "N":
                    parts.append(f"<{val}>")
                elif kind == "T":
                    parts.append(val.spell)
                else:
                    parts.append("\u03f5")
            rendered.append(" ".join(parts))
        lines.append(f"`<{lhs}> ::= {' | '.join(rendered)}`")
    return "\n".join(lines) + "\n"


# --- .g4 --------------------------------------------------------------------

def render_g4_parser():
    order, grouped = group_rules()
    out = []
    for lhs in order:
        out.append(backend_name(lhs))
        wrote = False
        for alt in grouped[lhs]:
            parts = []
            for sym in alt:
                kind, val = sym_kind(sym)
                if kind == "N":
                    parts.append(backend_name(val))
                elif kind == "T":
                    parts.append(val.name)
            out.append(("    : " if not wrote else "    | ") + " ".join(parts))
            wrote = True
        if not wrote:
            out.append("    : ")
        out.append("    ;")
        out.append("")
    return "\n".join(out)


def render_g4_lexer():
    out = []
    for f in spec.FRAGMENTS:
        out.append(f"fragment {f.name:<15} : {f.pattern} ;")
    out.append("")
    out.extend(f"{t.name} : {t.pattern} ;" for t in spec.TOKEN_RULES)
    out.append("")
    out.append("// Identifiers are declared after keywords to resolve length ties.")
    for t in spec.SKIP_RULES:
        out.append(f"{t.name} : {t.pattern} -> skip ;")
    return "\n".join(out) + "\n"


def render_g4():
    return ("grammar MiniJava;\n\n" + render_g4_parser().rstrip() + "\n\n"
            + render_g4_lexer())


# --- MiniJavaGrammar.java ---------------------------------------------------

def render_grammar_java_lines():
    lines = []
    for rule in spec.RULES:
        for alt in rule.alts:
            parts = [f"production({rule.lhs}"]
            for sym in alt:
                kind, val = sym_kind(sym)
                if kind == "N":
                    parts.append(val)
                elif kind == "T":
                    parts.append(val.name)
                else:
                    parts.append("EPSILON")
            lines.append("            " + ", ".join(parts) + ")")
    return ",\n".join(lines)


def render_grammar_java():
    return f"""\
package parser;

import java.util.List;

import static symbols.Epsilon.EPSILON;
import static symbols.NonTerminal.*;
import static symbols.Production.production;
import static symbols.TokenType.*;

// Production rules generated from minijava_spec.py by make_oracle_grammar.py.
public final class MiniJavaGrammar {{
    public static final Grammar GRAMMAR = new Grammar(List.of(
{render_grammar_java_lines()}
    ), Inicial);
}}
"""


# --- .jj --------------------------------------------------------------------

_JCC_ESCAPES = {"\t": "\\t", "\n": "\\n", "\r": "\\r", "\v": "\\v",
                "\f": "\\f", "\b": "\\b", "\\": "\\\\", '"': '\\"'}


def _jcc_str(ch):
    return '"' + _JCC_ESCAPES.get(ch, ch) + '"'


def _unescape(text):
    simple = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r",
              "'": "'", '"': '"', "\\": "\\"}
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if c == "\\" and i + 1 < n:
            out.append(simple.get(text[i + 1], text[i + 1]))
            i += 2
        else:
            out.append(c)
            i += 1
    return "".join(out)


def _jcc_class(text):
    negated = text.startswith("~")
    body = text[2:-1] if negated else text[1:-1]
    inner = _unescape(body)
    parts, i, n = [], 0, len(inner)
    while i < n:
        lo = inner[i]
        if i + 2 < n and inner[i + 1] == "-":
            parts.append(_jcc_str(lo) + "-" + _jcc_str(inner[i + 2]))
            i += 3
        else:
            parts.append(_jcc_str(lo))
            i += 1
    return ("~" if negated else "") + "[" + ",".join(parts) + "]"


def _jcc_literal(inner):
    inner = _unescape(inner)
    body = [_JCC_ESCAPES.get(ch, ch) for ch in inner]
    return '"' + "".join(body) + '"'


def _inline_fragments(pattern):
    def pad(pat):
        return lambda m: "(" + pat + ")"

    max_passes = len(FRAGMENT_INDEX) + 1
    for _ in range(max_passes):
        changed = False
        for name, pat in FRAGMENT_INDEX.items():
            ref = rf"(?<![A-Za-z0-9_]){name}(?![A-Za-z0-9_])"
            if re.search(ref, pattern):
                pattern = re.sub(ref, pad(pat), pattern)
                changed = True
        if not changed:
            break
    else:
        raise RuntimeError("fragment expansion did not converge")
    return pattern


def javacc_regex(pattern):
    p = _inline_fragments(pattern)
    cls = r"(?P<cls>~?\[[^\]]*\])"
    lit = r"'(?P<lit>(?:[^'\\]|\\.)*)'"
    p = re.sub(rf"(?:{cls}|{lit})(?P<q>[+*?])?", _jcc_convert, p)
    return p


def _jcc_convert(m):
    if m.group("cls") is not None:
        out = _jcc_class(m.group("cls"))
    else:
        out = _jcc_literal(m.group("lit"))
    q = m.group("q")
    return f"({out}){q}" if q else out


def _lexer_block(kind, rules):
    lines = [kind + " :", "{"]
    for i, t in enumerate(rules):
        sep = "    | " if i else "      "
        lines.append(f"{sep}<{t.name}: {javacc_regex(t.pattern)}>")
    lines.append("}")
    return "\n".join(lines)


def render_jj_lexer():
    return (_lexer_block("TOKEN", spec.TOKEN_RULES) + "\n\n"
            + _lexer_block("SKIP", spec.SKIP_RULES))


def render_jj_parser():
    order, grouped = group_rules()
    out = []
    for lhs in order:
        variants = []
        for alt in grouped[lhs]:
            parts = []
            for sym in alt:
                kind, val = sym_kind(sym)
                if kind == "N":
                    parts.append(backend_name(val) + "()")
                elif kind == "T":
                    parts.append(f"<{val.name}>")
            variants.append(" ".join(parts) if parts else "{}")
        body = "\n    | ".join(variants)
        out.append(f"void {backend_name(lhs)}() :\n{{}}\n{{\n    {body}\n}}")
    return "\n\n".join(out)


def render_jj():
    header = """\
options {
    STATIC = false;
}

PARSER_BEGIN(MiniJavaParser)

import java.io.*;
import java.nio.charset.StandardCharsets;

public class MiniJavaParser {

    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("usage: MiniJavaParser [--rules] <file>");
            System.exit(2);
        }
        boolean rules = false;
        String path;
        if (args[0].equals("--rules")) {
            rules = true;
            path = args[1];
        } else {
            path = args[0];
        }
        try {
            Reader r = new InputStreamReader(new FileInputStream(path), StandardCharsets.UTF_8);
            MiniJavaParser p = new MiniJavaParser(r);
            if (rules) { p.enable_tracing(); }
            p.inicial();
            System.out.println("OK");
        } catch (ParseException e) {
            Token t = e.currentToken.next;
            String img = (t == null || t.image == null || t.kind == 0) ? "$" : t.image;
            int line = (t == null) ? 0 : t.beginLine;
            System.out.println("[Error:" + img + "|" + (line + 1) + "]");
        } catch (TokenMgrError e) {
            System.out.println("[Error:$|0]");
        }
    }
}

PARSER_END(MiniJavaParser)
"""
    return (header.rstrip() + "\n\n" + render_jj_lexer().rstrip() + "\n\n"
            + render_jj_parser().rstrip() + "\n")


# --- driver ------------------------------------------------------------------

def main():
    artifacts = {
        OUT["spec"]: render_md(),
        OUT["g4"]: render_g4(),
        OUT["java"]: render_grammar_java(),
        OUT["jj"]: render_jj(),
    }
    for path, content in artifacts.items():
        path.write_text(content, encoding="utf-8")
        print("Wrote", path)


if __name__ == "__main__":
    main()

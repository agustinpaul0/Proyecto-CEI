#!/usr/bin/env python3
"""
generate_fuzz_cases.py

Drives Grammarinator and a JavaCC oracle generated from minijava_spec.py
to populate test suites with valid and invalid Java programs.
"""

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import re
from pathlib import Path
from urllib.request import urlretrieve
import antlerinator

# --- Constants & Paths ---
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
G4_PATH = SCRIPT_DIR / "grammar" / "MiniJava.g4"
JJ_PATH = SCRIPT_DIR / "grammar" / "MiniJavaParser.jj"
WORK_DIR = SCRIPT_DIR / "out"

TRANSFORMER = "avoid_keyword_identifiers.fix_keyword_identifiers"
GENERATOR_MODULE = "MiniJavaGenerator.MiniJavaGenerator"
START_RULE = "inicial"

JAVACC_URL = "https://repo1.maven.org/maven2/net/java/dev/javacc/javacc/7.0.13/javacc-7.0.13.jar"
DEFAULT_SEED_FILE = SCRIPT_DIR / "fuzz_seed.txt"

EXAMINED_BUDGET_PER_NEGATIVE = 10
SEED_STRIDE = 1_000_003
UNIQUE_ATTEMTPS = "100"

# Fixed output/staging directories
SIN_DIR = PROJECT_ROOT / "resources" / "parser" / "sinErrores"
CON_DIR = PROJECT_ROOT / "resources" / "parser" / "conErrores"
TREES_DIR = WORK_DIR / "population_trees"
STAGE_POS = WORK_DIR / "stage_pos"
STAGE_NEG = WORK_DIR / "stage_neg"
ORACLE_DIR = WORK_DIR / "javacc"

# Resolved binaries
JAVA = shutil.which("java")
JAVAC = shutil.which("javac")


def tool(name):
    found = shutil.which(name)
    if not found:
        sys.exit(f"ERROR: '{name}' not found on PATH. Run through `make fuzz`.")
    return found


def run(cmd, **kwargs):
    print(f"$ {' '.join(str(c) for c in cmd)}")
    return subprocess.run(cmd, check=True, **kwargs)


def run_capture(cmd):
    return subprocess.run(
        cmd, capture_output=True, text=True, encoding="utf-8", errors="replace"
    ).stdout


def sorted_by_number(folder: Path, prefix: str):
    return sorted(
        folder.glob(f"{prefix}_*.java"),
        key=lambda p: int(p.stem.rsplit("_", 1)[-1]),
    )


def parse_oracle(oracle: str):
    m = re.fullmatch(r"\[Error:(.*)\|(\d+)\]", oracle)
    return (m.group(1), int(m.group(2))) if m else None


def ensure_javacc_jar(target_path: Path) -> Path:
    """Ensures javacc.jar exists. Downloads it from Maven Central if missing."""
    target_path = target_path.resolve()
    target_path.parent.mkdir(parents=True, exist_ok=True)

    if not target_path.exists():
        print(f"Downloading JavaCC JAR to {target_path}...")
        urlretrieve(JAVACC_URL, target_path)
        print("Download complete.")

    return target_path


def grammarinator_generate_pos(out_pattern, n, depth, seed):
    run([
        tool("grammarinator-generate"), GENERATOR_MODULE,
        "--sys-path", str(WORK_DIR),
        "--sys-path", str(SCRIPT_DIR),
        "-r", START_RULE,
        "-t", TRANSFORMER,
        "-s", "grammarinator.runtime.simple_space_serializer",
        "-o", out_pattern,
        "-n", str(n),
        "-d", str(depth),
        "--random-seed", str(seed),
    ])


def grammarinator_generate_neg(out_pattern, n, depth, seed):
    run([
        tool("grammarinator-generate"), GENERATOR_MODULE,
        "--sys-path", str(WORK_DIR),
        "--sys-path", str(SCRIPT_DIR),
        "-r", START_RULE,
        "-t", TRANSFORMER,
        "-s", "grammarinator.runtime.simple_space_serializer",
        "-o", out_pattern,
        "-n", str(n),
        "-d", str(depth),
        "--random-seed", str(seed),
        "--population", str(TREES_DIR),
        "--no-generate", 
        "--no-recombine", 
        "--keep-trees",
        "--memo-size", str(n), 
        "--unique-attempts", UNIQUE_ATTEMTPS
    ])


def build_oracle(javacc_jar: Path):
    print("Building JavaCC oracle...")
    oracle_gen, oracle_cp = ORACLE_DIR / "gen", ORACLE_DIR / "cp"
    for d in (oracle_gen, oracle_cp):
        shutil.rmtree(d, ignore_errors=True)
        d.mkdir(parents=True)

    run([JAVA, "-cp", str(javacc_jar), "javacc", f"-OUTPUT_DIRECTORY={oracle_gen}", str(JJ_PATH)])

    oracle_sources = sorted(str(p) for p in oracle_gen.glob("*.java"))
    run([JAVAC, "-encoding", "UTF-8", "-d", str(oracle_cp)] + oracle_sources)

    return str(oracle_cp)


def javacc_oracle(paths, oracle_cp_arg):
    if not paths:
        return []

    results = []
    for path in paths:
        res = run_capture([
            JAVA, "-Dfile.encoding=UTF-8", "-cp", oracle_cp_arg,
            "MiniJavaParser", str(path),
        ]).strip()
        results.append(res)

    return results


def drain_stage(stage_dir: Path, prefix: str, seen: set):
    out = []
    for p in sorted_by_number(stage_dir, prefix):
        digest = hashlib.sha256(p.read_bytes()).hexdigest()
        if digest in seen:
            p.unlink()
            continue
        seen.add(digest)
        out.append(p)
    return out


def publish_negative(content, oracle, published):
    fields = parse_oracle(oracle)
    if fields is None:
        return False
    token, line = fields
    dest = CON_DIR / f"fuzz_neg_{published}.java"
    dest.write_bytes(f"// [Error:{token}|{line}]\n".encode("utf-8") + content)
    return True


def _process_positive_candidate(candidate: Path, published: int, kept_empty: bool) -> tuple[bool, bool]:
    content = candidate.read_bytes()
    if not content.strip():
        if kept_empty:
            candidate.unlink()
            return False, kept_empty
        kept_empty = True

    (SIN_DIR / f"fuzz_pos_{published}.java").write_bytes(content)
    candidate.unlink()
    return True, kept_empty


def run_fuzz_pipeline(label, target, step_fn, oversample_factor=1.5, max_budget=None):
    published, examined, attempt = 0, 0, 0

    while published < target:
        attempt += 1

        if max_budget and examined >= max_budget:
            print(f"[{label}] Stopping: Exceeded maximum budget ({examined}/{max_budget}).")
            break

        remaining = target - published
        batch_size = max(int(remaining * oversample_factor), 5)

        print(f"[{label}] Step {attempt} | Remaining: {remaining} | Requesting batch: {batch_size}")

        pub_delta, exam_delta = step_fn(attempt, batch_size, published, examined)
        published += pub_delta
        examined += exam_delta

        # If yield is low (< 50% of batch converted), scale up oversampling factor for next loop
        if exam_delta > 0:
            yield_rate = pub_delta / exam_delta
            if yield_rate < 0.5:
                oversample_factor = min(oversample_factor * 1.5, 4.0)  # Cap max oversampling at 4x

        if pub_delta == 0 and exam_delta == 0:
            print(f"[{label}] Warning: Zero candidates produced. Aborting loop.")
            break

    return published, examined


def generate_positives(target: int, max_attempts: int, depth: int, seed: int):
    shutil.rmtree(STAGE_POS, ignore_errors=True)
    STAGE_POS.mkdir()

    seen = set()
    kept_empty = False

    def step_positive(attempt, batch_size, published, examined):
        nonlocal kept_empty
        step_seed = seed + attempt * SEED_STRIDE
        out_pattern = str(STAGE_POS / f"fuzz_pos_{attempt}_%d.java")
        
        # Perturb depth slightly when retrying to break duplicate generation loops
        current_depth = depth + (attempt % 5) if attempt > max_attempts else depth
        grammarinator_generate_pos(out_pattern, batch_size, current_depth, step_seed)

        fresh = drain_stage(STAGE_POS, f"fuzz_pos_{attempt}", seen)
        pub_count = 0

        for candidate in fresh:
            if published + pub_count >= target:
                candidate.unlink()
                continue

            added, kept_empty = _process_positive_candidate(candidate, published + pub_count, kept_empty)
            if added:
                pub_count += 1

        return pub_count, len(fresh)

    published, _ = run_fuzz_pipeline("Positive Generation", target, step_positive)
    if published < target:
        sys.exit(f"ERROR: Could only generate {published}/{target} unique positive samples.")


def generate_negatives(target: int, max_attempts: int, depth: int, seed: int, oracle_cp_arg: str):
    if not any(TREES_DIR.iterdir()):
        sys.exit("ERROR: Negatives need tree population. Run positive generation first.")

    shutil.rmtree(STAGE_NEG, ignore_errors=True)
    STAGE_NEG.mkdir()

    budget = target * EXAMINED_BUDGET_PER_NEGATIVE
    seen = set()

    def step_negative(attempt, batch_size, published, examined):
        step_seed = seed + attempt * SEED_STRIDE
        out_pattern = str(STAGE_NEG / f"fuzz_neg_{attempt}_%d.java")
        grammarinator_generate_neg(out_pattern, batch_size, depth, step_seed)

        fresh = drain_stage(STAGE_NEG, f"fuzz_neg_{attempt}", seen)
        if not fresh:
            print("WARNING: Mutation space saturated.", file=sys.stderr)
            return 0, 0

        results = javacc_oracle(fresh, oracle_cp_arg)
        pub_count = 0
        exam_count = 0

        for candidate, oracle_res in zip(fresh, results):
            if published + pub_count >= target or (examined + exam_count) >= budget:
                candidate.unlink()
                continue

            exam_count += 1
            if publish_negative(candidate.read_bytes(), oracle_res, published + pub_count):
                pub_count += 1

            candidate.unlink()

        return pub_count, exam_count

    published, _ = run_fuzz_pipeline("Negative Mutation", target, step_negative, max_budget=budget)

    if published < target:
        sys.exit(f"ERROR: Only reached {published}/{target} negatives.")


def build_population(antlr_jar: Path):
    shutil.rmtree(TREES_DIR, ignore_errors=True)
    TREES_DIR.mkdir()
    sources = [p for p in sorted(SIN_DIR.glob("fuzz_pos_*.java")) if p.read_bytes().strip()]
    if not sources:
        return 0
    parse_cmd = [
        tool("grammarinator-parse"),
        *[str(s) for s in sources],
        "-g", str(G4_PATH),
        "-r", START_RULE,
        "-o", str(TREES_DIR),
        "--antlr", str(antlr_jar.resolve())
    ]
    run(parse_cmd)
    return len(list(TREES_DIR.iterdir()))


def main():
    ap = argparse.ArgumentParser(description="Generate parser fuzz test cases.")
    ap.add_argument("--num-positive", type=int, default=50)
    ap.add_argument("--num-negative", type=int, default=50)
    ap.add_argument("--max-depth", type=int, default=50)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--max-attempts", type=int, default=10)
    ap.add_argument("--antlr-jar", type=Path, default=None, help="Path to ANTLR JAR for grammarinator parser.")
    ap.add_argument("--javacc-jar", type=Path, default=None, help="Path to javacc.jar.")
    args = ap.parse_args()

    if not args.antlr_jar:
        print(f"Downloading ANTLR to {args.antlr_jar}...")
        antlerinator.download(lazy=True, path=str(args.antlr_jar))

    javacc_jar_path = ensure_javacc_jar(args.javacc_jar)

    if not JAVA or not JAVAC:
        sys.exit("ERROR: 'java' or 'javac' missing from PATH.")
    if not G4_PATH.is_file():
        sys.exit(f"ERROR: Grammar missing at {G4_PATH}")
    if not JJ_PATH.is_file():
        sys.exit(f"ERROR: JavaCC grammar missing at {JJ_PATH}. Run make_oracle_grammar.py first.")

    for d in (SIN_DIR, CON_DIR, TREES_DIR, STAGE_POS, STAGE_NEG, ORACLE_DIR):
        d.mkdir(parents=True, exist_ok=True)

    seed = args.seed if args.seed is not None else int.from_bytes(os.urandom(4), "big")
    DEFAULT_SEED_FILE.write_text(f"{seed}\n", encoding="utf-8")
    print(f"Generation seed: {seed}")

    oracle_cp_arg = build_oracle(javacc_jar_path)

    run([tool("grammarinator-process"), str(G4_PATH), "-o", str(WORK_DIR)])

    generate_positives(args.num_positive, args.max_attempts, args.max_depth, seed)
    build_population(args.antlr_jar)
    generate_negatives(args.num_negative, args.max_attempts, args.max_depth, seed, oracle_cp_arg)

    print("\nDone")


if __name__ == "__main__":
    main()

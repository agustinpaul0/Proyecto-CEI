grammar MiniJava;

inicial
    : listaClases EOF
    ;

listaClases
    : clase listaClases
    | interfaz listaClases
    | 
    ;

clase
    : CLASS ID_CLASS genericidadOpcional herenciaOpcional LBRACE listaMiembros RBRACE
    ;

interfaz
    : INTERFACE ID_CLASS genericidadOpcional extensionOpcional LBRACE listaMetodosInterfaz RBRACE
    ;

genericidadOpcional
    : LESS_THAN ID_TYPE GREATER_THAN
    | 
    ;

herenciaOpcional
    : EXTENDS tipoReferencia
    | IMPLEMENTS tipoReferencia
    | 
    ;

extensionOpcional
    : EXTENDS tipoReferencia
    | 
    ;

listaMiembros
    : miembro listaMiembros
    | 
    ;

listaMetodosInterfaz
    : metodoInterfaz listaMetodosInterfaz
    | 
    ;

miembro
    : STATIC metodoEstatico
    | VOID metodo
    | PUBLIC constructor
    | nombreTipado argsOPuntoYComa
    ;

metodoEstatico
    : tipoMetodo metodo
    ;

nombreTipado
    : tipo ID_VAR_METH
    ;

argsOPuntoYComa
    : argsFormales bloque
    | SEMICOLON
    ;

metodo
    : ID_VAR_METH argsFormales bloque
    ;

metodoInterfaz
    : tipoMetodo ID_VAR_METH argsFormales SEMICOLON
    ;

constructor
    : ID_CLASS argsFormales bloque
    ;

tipoMetodo
    : tipo
    | VOID
    ;

tipo
    : tipoBase dimensionesOpcionales
    ;

tipoBase
    : tipoPrimitivo
    | tipoReferencia
    | ID_TYPE
    ;

dimensionesOpcionales
    : LBRACKET RBRACKET dimensionesOpcionales
    | 
    ;

tipoReferencia
    : ID_CLASS tipoGenericoOpcional
    ;

tipoPrimitivo
    : BOOLEAN
    | CHAR
    | INT
    ;

tipoGenericoOpcional
    : LESS_THAN instanciadoOParametrico GREATER_THAN
    | 
    ;

instanciadoOParametrico
    : ID_TYPE
    | ID_CLASS
    ;

argsFormales
    : LPAREN listaArgsFormalesOpcional RPAREN
    ;

listaArgsFormalesOpcional
    : listaArgsFormales
    | 
    ;

listaArgsFormales
    : argFormal listaArgsFormalesR
    ;

listaArgsFormalesR
    : COMMA argFormal listaArgsFormalesR
    | 
    ;

argFormal
    : tipo ID_VAR_METH
    ;

bloque
    : LBRACE listaSentencias RBRACE
    ;

listaSentencias
    : sentencia listaSentencias
    | 
    ;

sentencia
    : SEMICOLON
    | expresion SEMICOLON
    | varLocal SEMICOLON
    | returnStmt SEMICOLON
    | ifStmt
    | whileStmt
    | bloque
    ;

varLocal
    : VAR ID_VAR_METH ASSIGNMENT expresionCompuesta
    ;

returnStmt
    : RETURN expresionOpcional
    ;

expresionOpcional
    : expresion
    | 
    ;

ifStmt
    : IF LPAREN expresion RPAREN sentencia orElse
    ;

orElse
    : ELSE sentencia
    | 
    ;

whileStmt
    : WHILE LPAREN expresion RPAREN sentencia
    ;

expresion
    : expresionCompuesta expresionR
    ;

expresionR
    : operadorAsignacion expresionCompuesta expresionR
    | 
    ;

operadorAsignacion
    : ASSIGNMENT
    ;

expresionCompuesta
    : expresionBasica expresionCompuestaR
    ;

expresionCompuestaR
    : operadorBinario expresionBasica expresionCompuestaR
    | 
    ;

operadorBinario
    : LOGICAL_OR
    | LOGICAL_AND
    | EQUALITY
    | INEQUALITY
    | LESS_THAN
    | GREATER_THAN
    | LESS_OR_EQUAL
    | GREATER_OR_EQUAL
    | PLUS
    | MINUS
    | ASTERISK
    | SLASH
    | PERCENT
    ;

expresionBasica
    : operadorUnario operando
    | operando
    ;

operadorUnario
    : PLUS
    | MINUS
    | BANG
    ;

operando
    : primitivo
    | referencia
    ;

primitivo
    : LIT_BOOLEAN
    | LIT_INTEGER
    | LIT_CHAR
    | LIT_NULL
    ;

referencia
    : primario referenciaR
    ;

referenciaR
    : encadenado referenciaR
    | accesoArreglo referenciaR
    | 
    ;

encadenado
    : DOT ID_VAR_METH argsMetodoEncadenado
    ;

argsMetodoEncadenado
    : argsActuales
    | 
    ;

accesoArreglo
    : LBRACKET expresion RBRACKET
    ;

primario
    : THIS
    | LIT_STRING
    | varOLlamadaMetodo
    | newExpr
    | llamadaMetodoEstatico
    | expresionParentizada
    ;

varOLlamadaMetodo
    : ID_VAR_METH llamadaMetodoOpcional
    ;

newExpr
    : NEW objetoOArreglo
    ;

objetoOArreglo
    : tipoReferencia objetoOArregloOtraVez
    | crearArreglo
    ;

objetoOArregloOtraVez
    : dimensionesConTamanio
    | argsActuales
    ;

crearArreglo
    : ID_TYPE dimensionesConTamanio
    | tipoPrimitivo dimensionesConTamanio
    ;

llamadaMetodoOpcional
    : argsActuales
    | 
    ;

llamadaMetodoEstatico
    : ID_CLASS DOT ID_VAR_METH argsActuales
    ;

expresionParentizada
    : LPAREN expresion RPAREN
    ;

dimensionesConTamanio
    : LBRACKET expresion RBRACKET dimensionesConTamanioR
    ;

dimensionesConTamanioR
    : LBRACKET expresion RBRACKET dimensionesConTamanioR
    | 
    ;

argsActuales
    : LPAREN listaExpsOpcional RPAREN
    ;

listaExpsOpcional
    : listaExps
    | 
    ;

listaExps
    : expresion listaExpsR
    ;

listaExpsR
    : COMMA expresion listaExpsR
    | 
    ;

fragment CHAR_ENTRADA    : ~[\r\n] ;
fragment SINGLE_CHAR     : ~['\\\r\n] ;
fragment STRING_CHAR     : ~["\\\r\n] ;
fragment NO_STAR         : ~[*] ;
fragment NO_STAR_SLASH   : ~[*/] ;
fragment LINE_TERM       : '\r\n' | '\r' | '\n' ;
fragment UPPER           : [A-Z] ;
fragment LOWER           : [a-z] ;
fragment DIGIT           : [0-9] ;
fragment WHITESPACE_CHAR : LINE_TERM | '\t' | ' ' ;
fragment HEX             : DIGIT | [A-Fa-f] ;
fragment ESCAPABLE       : [btnfr"'\\] ;
fragment ESCAPE_SEQUENCE : '\\' (ESCAPABLE | 'u'+ HEX HEX HEX HEX) ;
fragment EXPONENTE       : [eE] [+-]? DIGIT+ ;
fragment SUFIJO_FLOAT    : [fFdD] ;

ASSIGNMENT : '=' ;
ASTERISK : '*' ;
BANG : '!' ;
BOOLEAN : 'boolean' ;
CHAR : 'char' ;
CLASS : 'class' ;
COMMA : ',' ;
DOT : '.' ;
ELSE : 'else' ;
EQUALITY : '==' ;
EXTENDS : 'extends' ;
GREATER_OR_EQUAL : '>=' ;
GREATER_THAN : '>' ;
IF : 'if' ;
IMPLEMENTS : 'implements' ;
INEQUALITY : '!=' ;
INT : 'int' ;
INTERFACE : 'interface' ;
LBRACE : '{' ;
LBRACKET : '[' ;
LESS_OR_EQUAL : '<=' ;
LESS_THAN : '<' ;
LIT_BOOLEAN : 'true' | 'false' ;
LIT_CHAR : '\'' (SINGLE_CHAR | ESCAPE_SEQUENCE) '\'' ;
LIT_INTEGER : DIGIT DIGIT? DIGIT? DIGIT? DIGIT? DIGIT? DIGIT? DIGIT? DIGIT? ;
LIT_NULL : 'null' ;
LIT_STRING : '"' (STRING_CHAR | ESCAPE_SEQUENCE)* '"' ;
LOGICAL_AND : '&&' ;
LOGICAL_OR : '||' ;
LPAREN : '(' ;
MINUS : '-' ;
NEW : 'new' ;
PERCENT : '%' ;
PLUS : '+' ;
PUBLIC : 'public' ;
RBRACE : '}' ;
RBRACKET : ']' ;
RETURN : 'return' ;
RPAREN : ')' ;
SEMICOLON : ';' ;
SLASH : '/' ;
STATIC : 'static' ;
THIS : 'this' ;
VAR : 'var' ;
VOID : 'void' ;
WHILE : 'while' ;
ID_CLASS : UPPER (LOWER | '_' | UPPER | DIGIT)+ ;
ID_TYPE : UPPER ;
ID_VAR_METH : LOWER (LOWER | '_' | UPPER | DIGIT)* ;

// Identifiers are declared after keywords to resolve length ties.
COMMENT_LINEA : '//' CHAR_ENTRADA* -> skip ;
COMMENT_MULTILINEA : '/*' (NO_STAR | '*'+ NO_STAR_SLASH)* '*'+ '/' -> skip ;
WS : WHITESPACE_CHAR+ -> skip ;

import sys
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent.parent

sys.path.insert(0, str(TOOLS_DIR / "grammar_from_spec"))

import minijava_spec as spec
from grammarinator.runtime import Rule, UnlexerRule

# Keep this in sync with KNOWN_LITERALS / BEST_GUESS_LEXER_RULES in
# java_grammar_to_g4.py if you add new keywords to the grammar.
RESERVED_KEYWORDS = set(map(lambda token: token.spell, spec.KEYWORDS.values()))

# Suffix appended to dodge a collision. No reserved keyword ends in "_",
# so a single append can never accidentally produce a *different* keyword.
SAFE_SUFFIX = "_"

def fix_keyword_identifiers(root: Rule) -> Rule:
    _walk(root)
    return root

def _walk(node: Rule) -> None:
    if isinstance(node, UnlexerRule):
        if node.name == "ID_VAR_METH" and node.src in RESERVED_KEYWORDS:
            node.src = node.src + SAFE_SUFFIX
        return
    for child in getattr(node, "children", ()):
        _walk(child)

// [Error:void|7]
interface I8 < J > extends T_pm70 < B > {
}
interface F0F extends Cq < A > {
void h1VG_ ( ) ;
}
void wQ ( S w_S , boolean [ ] m , V z2N4hh ) ;
package catedra;

import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import minijava.aplicacion.Main;
import minijava.casos.RequisitosDeLogrosDelCaso;
import minijava.logros.ConfiguracionDeLaCorrida;
import minijava.casos.VolcadoDeCasos;
import org.hamcrest.CoreMatchers;
import org.junit.After;
import org.junit.Assume;
import org.junit.AfterClass;
import org.junit.Test;
import org.junit.Before;
import org.junit.jupiter.api.Tag;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import static org.hamcrest.MatcherAssert.assertThat;

// Tester de la cátedra, con su criterio intacto: exige [SinErrores] y compara la
// secuencia impresa contra las expectativas //#lexema,nroLinea del propio caso.
// Sólo lexema y línea: la cátedra no fija los nombres internos de cada proyecto.
@RunWith(Parameterized.class)
@Tag("lexico")
public class TesterDeCasosSinErrores {

    private static final String ARGUMENTO_DE_LOGROS =
            ConfiguracionDeLaCorrida.comoArgumentoDeLinea();

    private static final String MSG_EXITO = "[SinErrores]";
    private static final String TEST_FILES_DIRECTORY_PATH = "resources/lexico/sinErrores/";
    private static final String EXPECTED_TOKEN_PREFIX = "//#";

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    // Estática y capturada al cargar la clase: setUp() redirige System.out para
    // capturar al compilador, y @AfterClass no ve los campos de instancia.
    private static final PrintStream CONSOLA = System.out;

    private final String input;

    public TesterDeCasosSinErrores(String input) {
        this.input = input;
    }

    @Before
    public void setUp() {
        outContent.reset();
        System.setOut(new PrintStream(outContent));
    }

    @After
    public void tearDown() {
        System.setOut(CONSOLA);
    }

    @Parameterized.Parameters(name = "{0}")
    public static Iterable<String> data() {
        File folder = new File(TEST_FILES_DIRECTORY_PATH);
        File[] files = folder.listFiles();

        if (files == null) {
            throw new RuntimeException(
                    "No se pudo leer el directorio de casos de prueba: "
                            + TEST_FILES_DIRECTORY_PATH
            );
        }

        List<String> names = new ArrayList<>();

        for (File file : files) {
            if (file.isFile()) {
                names.add(file.getName());
            }
        }

        Collections.sort(names);
        return names;
    }

    @AfterClass
    public static void informarElCorpusProcesado() {
        VolcadoDeCasos.resumirDirectorio(CONSOLA, TEST_FILES_DIRECTORY_PATH);
    }

    @Test
    public void testIterado() {
        probarExito(input);
    }

    private void probarExito(String name) {
        String path = TEST_FILES_DIRECTORY_PATH + name;
        saltearSiNoAplicaAEstaCorrida(path);

        List<TokenEsperado> tokensEsperados = leerTokensEsperados(path);

        invocarCompilador(path);

        String salida = outContent.toString();

        // CONSOLA y no System.out: setUp() lo tiene redirigido para capturar al
        // compilador. Qué imprime lo decide -Dvolcado (VolcadoDeCasos).
        VolcadoDeCasos.volcar(CONSOLA, path, salida);

        assertThat(
                "No se informo analisis exitoso en: " + path
                        + "\nSalida obtenida:\n" + salida,
                salida,
                CoreMatchers.containsString(MSG_EXITO)
        );

        List<TokenEsperado> tokensObtenidos = extraerTokensImpresos(salida, path);

        assertThat(
                "Cantidad incorrecta de tokens en: " + path
                        + "\nEsperados: " + tokensEsperados
                        + "\nObtenidos: " + tokensObtenidos
                        + "\nSalida completa:\n" + salida,
                tokensObtenidos.size(),
                CoreMatchers.is(tokensEsperados.size())
        );

        for (int i = 0; i < tokensEsperados.size(); i++) {
            TokenEsperado esperado = tokensEsperados.get(i);
            TokenEsperado obtenido = tokensObtenidos.get(i);

            assertThat(
                    "Lexema incorrecto en el token " + (i + 1) + " de " + path
                            + "\nEsperado: " + esperado
                            + "\nObtenido: " + obtenido
                            + "\nSalida completa:\n" + salida,
                    obtenido.lexema,
                    CoreMatchers.is(esperado.lexema)
            );

            assertThat(
                    "Numero de linea incorrecto en el token " + (i + 1) + " de " + path
                            + "\nEsperado: " + esperado
                            + "\nObtenido: " + obtenido
                            + "\nSalida completa:\n" + salida,
                    obtenido.linea,
                    CoreMatchers.is(esperado.linea)
            );
        }
    }

    // Invocado in-process una vez por caso: por eso Main no puede llamar a
    // System.exit() (mataría la corrida) ni guardar estado estático mutable.
    private void invocarCompilador(String rutaDelFuente) {
        Main.main(new String[] { "--etapa=1", ARGUMENTO_DE_LOGROS, rutaDelFuente });
    }

    // Un caso cuyos requisitos de logros no se cumplen en esta corrida se SALTEA
    // (JUnit 4 lo hace con Assume), no falla. Ver RequisitosDeLogrosDelCaso.
    private void saltearSiNoAplicaAEstaCorrida(String rutaDelFuente) {
        var requisitos = RequisitosDeLogrosDelCaso.de(Path.of(rutaDelFuente));
        var configuracion = ConfiguracionDeLaCorrida.actual();
        Assume.assumeTrue(
                rutaDelFuente + ": no aplica a esta configuracion de logros ("
                        + requisitos.describirIncumplidos(configuracion) + ")",
                requisitos.seCumplenEn(configuracion));
    }

    /*
     * Cada expectativa se escribe en una linea de comentario, preferentemente
     * al final del archivo fuente, con el siguiente formato estricto:
     *
     * //#<lexema>,<numeroDeLinea>
     *
     * Ejemplo:
     *
     * class A {
     * }
     * //#class,1
     * //#A,1
     * //#{,1
     * //#},2
     *
     * El lexema es la secuencia textual exacta reconocida en el fuente. Por eso:
     *
     * "hola"    -> //#"hola",1
     * 'c'        -> //#'c',2
     * '\n'       -> //#'\n',3
     *
     * Se toma la ultima coma como separador. Asi tambien se admiten lexemas que
     * contienen comas, por ejemplo: //#"hola, mundo",1
     */
    private List<TokenEsperado> leerTokensEsperados(String path) {
        List<TokenEsperado> tokensEsperados = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line;
            int sourceLineNumber = 0;

            while ((line = reader.readLine()) != null) {
                sourceLineNumber++;

                if (line.startsWith(EXPECTED_TOKEN_PREFIX)) {
                    tokensEsperados.add(
                            parsearTokenEsperado(
                                    line.substring(EXPECTED_TOKEN_PREFIX.length()),
                                    path,
                                    sourceLineNumber
                            )
                    );
                }
            }

        } catch (IOException exception) {
            throw new RuntimeException("No se pudo leer el caso de prueba: " + path, exception);
        }

        return tokensEsperados;
    }

    private TokenEsperado parsearTokenEsperado(
            String expectedTokenText,
            String path,
            int sourceLineNumber
    ) {
        int lastComma = expectedTokenText.lastIndexOf(',');

        if (lastComma < 0) {
            throw new RuntimeException(
                    "Expectativa invalida en " + path + ", linea " + sourceLineNumber
                            + ". Se esperaba el formato: //#<lexema>,<numeroDeLinea>"
            );
        }

        String lexema = expectedTokenText.substring(0, lastComma);
        String lineNumberText = expectedTokenText.substring(lastComma + 1).trim();

        try {
            return new TokenEsperado(lexema, Integer.parseInt(lineNumberText));
        } catch (NumberFormatException exception) {
            throw new RuntimeException(
                    "Numero de linea invalido en " + path + ", linea " + sourceLineNumber
                            + ": " + lineNumberText,
                    exception
            );
        }
    }

    /*
     * Se ignora el primer campo de la salida del alumno, porque no
     * fijamos los nombres internos de tokens. Solo se verifican lexema y linea.
     *
     * Se toma la primera y la ultima coma para admitir lexemas con comas:
     * (NombreToken,Lexema,NroLinea)
     */
    private List<TokenEsperado> extraerTokensImpresos(String salida, String path) {
        List<TokenEsperado> tokens = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new StringReader(salida))) {
            String line;
            int outputLineNumber = 0;

            while ((line = reader.readLine()) != null) {
                outputLineNumber++;
                String trimmedLine = line.trim();

                if (trimmedLine.startsWith("(") && trimmedLine.endsWith(")")) {
                    tokens.add(parsearTokenImpreso(trimmedLine, path, outputLineNumber));
                }
            }

        } catch (IOException exception) {
            // StringReader no produce IOException durante una lectura normal.
            throw new RuntimeException("No se pudo procesar la salida de: " + path, exception);
        }

        return tokens;
    }

    private TokenEsperado parsearTokenImpreso(
            String tokenImpreso,
            String path,
            int outputLineNumber
    ) {
        int firstComma = tokenImpreso.indexOf(',');
        int lastComma = tokenImpreso.lastIndexOf(',');

        if (firstComma <= 1 || lastComma <= firstComma || lastComma >= tokenImpreso.length() - 2) {
            throw new AssertionError(
                    "Formato de token invalido en la salida de " + path
                            + ", linea de salida " + outputLineNumber + ": " + tokenImpreso
                            + "\nSe esperaba: (NombreToken,Lexema,NroLinea)"
            );
        }

        String lexema = tokenImpreso.substring(firstComma + 1, lastComma);
        String lineNumberText = tokenImpreso
                .substring(lastComma + 1, tokenImpreso.length() - 1)
                .trim();

        try {
            return new TokenEsperado(lexema, Integer.parseInt(lineNumberText));
        } catch (NumberFormatException exception) {
            throw new AssertionError(
                    "El numero de linea no es valido en la salida de " + path
                            + ", linea de salida " + outputLineNumber + ": " + tokenImpreso
            );
        }
    }

    private static class TokenEsperado {
        private final String lexema;
        private final int linea;

        private TokenEsperado(String lexema, int linea) {
            this.lexema = lexema;
            this.linea = linea;
        }

        @Override
        public String toString() {
            return "(" + lexema + "," + linea + ")";
        }
    }
}

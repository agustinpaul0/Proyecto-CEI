package minijava.lexico.contexto;

import minijava.lexico.errores.EscapadorDeNoImprimibles;
import minijava.lexico.errores.ExcepcionLexica;
import minijava.lexico.errores.PosicionLexica;
import minijava.lexico.errores.TipoDeErrorLexico;

// Punto único de construcción de ExcepcionLexica: ningún estado la arma a mano,
// para que lexema y posición sean siempre consistentes entre sí. Lo único que
// varía entre un error y otro es el ancla; el BuilderDeLexema la resuelve.
public final class FabricaDeExcepcionesLexicas {

    private final BuilderDeLexema lexema;

    public FabricaDeExcepcionesLexicas(BuilderDeLexema lexema) {
        this.lexema = lexema;
    }

    public ExcepcionLexica crearExcepcionLexica(TipoDeErrorLexico tipo, AnclaDeError ancla) {
        return new ExcepcionLexica(tipo, EscapadorDeNoImprimibles.escapar(lexema.getLexema()),
                lexema.posicionDe(ancla));
    }

    // Única con posición explícita: la apertura de un comentario multilínea, cuyo
    // lexema ya descartó EstadoBarra y que no es reconstruible en el throw.
    public ExcepcionLexica crearExcepcionLexicaEn(TipoDeErrorLexico tipo, String lexemaOfensivo,
                                                  PosicionLexica posicion) {
        return new ExcepcionLexica(tipo, EscapadorDeNoImprimibles.escapar(lexemaOfensivo), posicion);
    }
}

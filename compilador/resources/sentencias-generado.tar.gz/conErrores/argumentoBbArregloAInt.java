///[Error:f|7]
// Bb[] a un parametro int (§9, §11.6)
class Uso {
    void v() { }
    void f(int p) { }
    void m(int d, Bb[] s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

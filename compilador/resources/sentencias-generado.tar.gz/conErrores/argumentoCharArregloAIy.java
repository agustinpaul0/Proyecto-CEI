///[Error:f|7]
// char[] a un parametro Iy (§9, §11.6)
class Uso {
    void v() { }
    void f(Iy p) { }
    void m(Iy d, char[] s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

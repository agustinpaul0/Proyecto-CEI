///[Error:f|7]
// Aa a un parametro Dd (§9, §11.6)
class Uso {
    void v() { }
    void f(Dd p) { }
    void m(Dd d, Aa s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

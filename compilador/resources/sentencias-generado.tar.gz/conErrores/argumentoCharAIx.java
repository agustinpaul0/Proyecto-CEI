///[Error:f|7]
// char a un parametro Ix (§9, §11.6)
class Uso {
    void v() { }
    void f(Ix p) { }
    void m(Ix d, char s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

///[Error:f|7]
// Cc a un parametro char (§9, §11.6)
class Uso {
    void v() { }
    void f(char p) { }
    void m(char d, Cc s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

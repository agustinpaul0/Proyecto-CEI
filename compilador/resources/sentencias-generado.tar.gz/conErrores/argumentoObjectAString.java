///[Error:f|7]
// Object a un parametro String (§9, §11.6)
class Uso {
    void v() { }
    void f(String p) { }
    void m(String d, Object s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

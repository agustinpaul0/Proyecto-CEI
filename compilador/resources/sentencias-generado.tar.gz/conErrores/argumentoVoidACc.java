///[Error:f|7]
// void a un parametro Cc (§9, §11.6)
class Uso {
    void v() { }
    void f(Cc p) { }
    void m(Cc d) {
        f(v()); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

///[Error:f|7]
// Caja<String> a un parametro Caja<String>[] (§9, §11.6)
class Uso {
    void v() { }
    void f(Caja<String>[] p) { }
    void m(Caja<String>[] d, Caja<String> s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

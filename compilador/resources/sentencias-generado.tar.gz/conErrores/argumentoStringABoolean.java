///[Error:f|7]
// String a un parametro boolean (§9, §11.6)
class Uso {
    void v() { }
    void f(boolean p) { }
    void m(boolean d, String s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

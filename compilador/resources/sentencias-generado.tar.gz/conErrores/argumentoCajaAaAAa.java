///[Error:f|7]
// Caja<Aa> a un parametro Aa (§9, §11.6)
class Uso {
    void v() { }
    void f(Aa p) { }
    void m(Aa d, Caja<Aa> s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

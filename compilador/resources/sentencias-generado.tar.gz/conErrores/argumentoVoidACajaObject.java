///[Error:f|7]
// void a un parametro Caja<Object> (§9, §11.6)
class Uso {
    void v() { }
    void f(Caja<Object> p) { }
    void m(Caja<Object> d) {
        f(v()); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

///[Error:f|7]
// Ix a un parametro Ix[] (§9, §11.6)
class Uso {
    void v() { }
    void f(Ix[] p) { }
    void m(Ix[] d, Ix s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

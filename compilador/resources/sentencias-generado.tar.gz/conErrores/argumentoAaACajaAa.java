///[Error:f|7]
// Aa a un parametro Caja<Aa> (§9, §11.6)
class Uso {
    void v() { }
    void f(Caja<Aa> p) { }
    void m(Caja<Aa> d, Aa s) {
        f(s); // <-
    }
}

interface Ix { }
interface Iy extends Ix { }
class Aa { }
class Bb extends Aa { }
class Cc extends Bb { }
class Dd implements Iy { }
class Caja<T> { }

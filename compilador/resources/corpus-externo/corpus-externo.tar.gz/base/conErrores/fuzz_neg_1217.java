// [Error:,|7]
interface VV < H > {
}
class Jn < K > implements N_VZ_ {
}
class UJ implements KB {
void rT_ ( int q_hl_6 , K [ ] [ ] , Bx < GH_ > [ ] ra_ , K k , X kY ) {
}
}
interface GL_ < W > {
}
interface Z_ < A > {
}
interface BGS < F > extends Fu {
}
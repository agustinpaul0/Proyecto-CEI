// [Error:extends|2]
extends N2